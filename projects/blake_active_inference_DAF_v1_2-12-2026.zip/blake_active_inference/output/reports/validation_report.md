# Validation Report

**Generated:** 2026-02-12T13:18:53.337074

## Validation Checks

- ✅ PASS: PDF validation
- ✅ PASS: Markdown validation
- ✅ PASS: Output structure
- ❌ FAIL: Figure registry
